# spectreRSB-POC

A simple POC of spectreRSB

Paper link：http://arxiv.org/pdf/1807.07940

#usage

make clean

make

./main

